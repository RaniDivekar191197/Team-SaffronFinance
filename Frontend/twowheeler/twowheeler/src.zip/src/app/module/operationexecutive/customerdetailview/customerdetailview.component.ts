import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerdetailview',
  templateUrl: './customerdetailview.component.html',
  styleUrls: ['./customerdetailview.component.css']
})
export class CustomerdetailviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
