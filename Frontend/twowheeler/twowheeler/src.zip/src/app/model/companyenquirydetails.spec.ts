import { Companyenquirydetails } from './companyenquirydetails';

describe('Companyenquirydetails', () => {
  it('should create an instance', () => {
    expect(new Companyenquirydetails()).toBeTruthy();
  });
});
