export class Cibil {
    cibilpanid:String;
    cibilscore:number;
    cibilstatus:string;
    cibilremark:string;
    
}
