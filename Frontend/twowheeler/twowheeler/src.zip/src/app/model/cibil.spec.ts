import { Cibil } from './cibil';

describe('Cibil', () => {
  it('should create an instance', () => {
    expect(new Cibil()).toBeTruthy();
  });
});
