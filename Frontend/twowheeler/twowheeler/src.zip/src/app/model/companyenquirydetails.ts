export class Companyenquirydetails {

    enqId:number;
    companyname:string;
    companypan:string;
    companyemailid:string;
    companycontactnumber:any;
    cityname:string;
    loanamountrequired:string;
}
