export class Document {


     documentId:number;
	 companyEnqId:number;
	 panCard:any
	 rentAggrement:any
	 companyPhotos:any
	 bankStatement:any
	 cancelCheckPhoto:any
	 incomeTaxReturns:any
	 signaturePhoto:any
	 quotationPhoto:any
}
