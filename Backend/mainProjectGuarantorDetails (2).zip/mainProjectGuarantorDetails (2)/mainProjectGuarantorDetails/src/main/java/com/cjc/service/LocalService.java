package com.cjc.service;

import com.cjc.model.LocalAddress;

public interface LocalService {

	void saveLocalAddress(LocalAddress pa);

}
