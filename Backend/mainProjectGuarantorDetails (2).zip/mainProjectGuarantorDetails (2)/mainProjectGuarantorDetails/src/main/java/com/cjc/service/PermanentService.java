package com.cjc.service;

import com.cjc.model.PermanentAddress;

public interface PermanentService {

	void savePermanentAddress(PermanentAddress pa);
	
	

}
