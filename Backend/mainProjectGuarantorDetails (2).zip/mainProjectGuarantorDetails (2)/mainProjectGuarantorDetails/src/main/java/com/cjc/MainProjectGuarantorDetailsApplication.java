package com.cjc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MainProjectGuarantorDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainProjectGuarantorDetailsApplication.class, args);
	}

}
