package com.cjc.service;

import com.cjc.model.PreviousLoanDetails;

public interface LoanService {

	void savePreviousLoanDetails(PreviousLoanDetails pld);
	
	

}
