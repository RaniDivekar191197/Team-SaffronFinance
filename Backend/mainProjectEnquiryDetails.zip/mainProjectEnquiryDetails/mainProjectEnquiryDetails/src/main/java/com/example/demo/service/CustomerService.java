package com.example.demo.service;

import java.util.List;

import com.example.demo.model.LoanEmiCalculation;

public interface CustomerService
{

	
	
	public void emiData(LoanEmiCalculation lec);
	
	public List<LoanEmiCalculation> getloan();
	
	
	

	
	
	
}
