package com.cjc.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailSenderProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmailSenderProject1Application.class, args);
	}

}
